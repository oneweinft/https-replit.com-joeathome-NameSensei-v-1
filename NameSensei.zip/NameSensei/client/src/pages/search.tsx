import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Search as SearchIcon,
  Globe,
  Shield,
  Check,
  ChevronLeft,
} from "lucide-react";
import { SiX } from "react-icons/si";

export default function Search() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedJurisdictions, setSelectedJurisdictions] = useState<string[]>([
    "australasia",
    "europe",
    "usa",
  ]);
  const [selectedCheckTypes, setSelectedCheckTypes] = useState<string[]>([
    "domain",
    "social",
    "trademark",
  ]);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const searchMutation = useMutation({
    mutationFn: async (data: {
      searchTerm: string;
      jurisdictions: string[];
      checkTypes: string[];
    }) => {
      const response = await apiRequest("POST", "/api/searches", data);
      return response;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/searches/recent"] });
      toast({
        title: "Search Started",
        description: "Your search is being processed...",
      });
      setLocation(`/results/${data.id}`);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Search Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!searchTerm.trim()) {
      toast({
        title: "Invalid Input",
        description: "Please enter a business name to search",
        variant: "destructive",
      });
      return;
    }

    if (selectedJurisdictions.length === 0) {
      toast({
        title: "Invalid Selection",
        description: "Please select at least one jurisdiction",
        variant: "destructive",
      });
      return;
    }

    if (selectedCheckTypes.length === 0) {
      toast({
        title: "Invalid Selection",
        description: "Please select at least one check type",
        variant: "destructive",
      });
      return;
    }

    if (user && (user.searchesRemaining ?? 0) <= 0) {
      toast({
        title: "No Searches Remaining",
        description: "Please upgrade your plan to continue searching",
        variant: "destructive",
      });
      setLocation("/subscription");
      return;
    }

    searchMutation.mutate({
      searchTerm: searchTerm.trim(),
      jurisdictions: selectedJurisdictions,
      checkTypes: selectedCheckTypes,
    } as any);
  };

  const toggleJurisdiction = (jurisdiction: string) => {
    setSelectedJurisdictions((prev) =>
      prev.includes(jurisdiction)
        ? prev.filter((j) => j !== jurisdiction)
        : [...prev, jurisdiction]
    );
  };

  const toggleCheckType = (checkType: string) => {
    setSelectedCheckTypes((prev) =>
      prev.includes(checkType)
        ? prev.filter((c) => c !== checkType)
        : [...prev, checkType]
    );
  };

  const getInitials = () => {
    if (!user) return "U";
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.email) {
      return user.email.substring(0, 2).toUpperCase();
    }
    return "U";
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <SearchIcon className="w-5 h-5 text-primary" />
              </div>
              <span className="text-xl font-bold">NameCheck</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => setLocation("/profile")}
              data-testid="button-profile"
            >
              <Avatar className="w-8 h-8 mr-2">
                <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} className="object-cover" />
                <AvatarFallback>{getInitials()}</AvatarFallback>
              </Avatar>
              <span className="hidden sm:inline">{user.firstName || user.email}</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4" data-testid="text-page-title">
            Search Your Business Name
          </h1>
          <p className="text-lg text-muted-foreground">
            Check availability across domains, social media, and trademarks
          </p>
          <div className="mt-4">
            <Badge variant="secondary" data-testid="badge-searches-remaining">
              {user.searchesRemaining ?? 0} searches remaining
            </Badge>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Search Input */}
          <Card className="p-8">
            <Label htmlFor="search-term" className="text-lg font-semibold mb-4 block">
              Business Name
            </Label>
            <Input
              id="search-term"
              type="text"
              placeholder="Enter your business name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-lg h-14"
              data-testid="input-search-term"
              autoFocus
            />
            <p className="text-sm text-muted-foreground mt-2">
              Enter the exact name you want to check
            </p>
          </Card>

          {/* Jurisdiction Selection */}
          <Card className="p-8">
            <Label className="text-lg font-semibold mb-4 block">
              Select Jurisdictions
            </Label>
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { id: "australasia", label: "Australasia", flag: "🇦🇺" },
                { id: "europe", label: "Europe", flag: "🇪🇺" },
                { id: "usa", label: "United States", flag: "🇺🇸" },
              ].map((jurisdiction) => (
                <button
                  key={jurisdiction.id}
                  type="button"
                  onClick={() => toggleJurisdiction(jurisdiction.id)}
                  className={`p-4 rounded-lg border-2 transition-all hover-elevate ${
                    selectedJurisdictions.includes(jurisdiction.id)
                      ? "border-primary bg-primary/5"
                      : "border-border"
                  }`}
                  data-testid={`button-jurisdiction-${jurisdiction.id}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl">{jurisdiction.flag}</span>
                    {selectedJurisdictions.includes(jurisdiction.id) && (
                      <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                        <Check className="w-4 h-4 text-primary-foreground" />
                      </div>
                    )}
                  </div>
                  <p className="font-semibold text-left">{jurisdiction.label}</p>
                </button>
              ))}
            </div>
          </Card>

          {/* Check Type Selection */}
          <Card className="p-8">
            <Label className="text-lg font-semibold mb-4 block">
              What to Check
            </Label>
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                {
                  id: "domain",
                  label: "Domain Names",
                  icon: Globe,
                  description: ".com, .au, .eu, .us",
                },
                {
                  id: "social",
                  label: "Social Media",
                  icon: SiX,
                  description: "X, Instagram, etc.",
                },
                {
                  id: "trademark",
                  label: "Trademarks",
                  icon: Shield,
                  description: "Official registries",
                },
              ].map((checkType) => {
                const Icon = checkType.icon;
                return (
                  <button
                    key={checkType.id}
                    type="button"
                    onClick={() => toggleCheckType(checkType.id)}
                    className={`p-4 rounded-lg border-2 transition-all hover-elevate ${
                      selectedCheckTypes.includes(checkType.id)
                        ? "border-primary bg-primary/5"
                        : "border-border"
                    }`}
                    data-testid={`button-checktype-${checkType.id}`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      {selectedCheckTypes.includes(checkType.id) && (
                        <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                          <Check className="w-4 h-4 text-primary-foreground" />
                        </div>
                      )}
                    </div>
                    <p className="font-semibold text-left mb-1">{checkType.label}</p>
                    <p className="text-xs text-muted-foreground text-left">
                      {checkType.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Submit Button */}
          <div className="flex justify-center pt-4">
            <Button
              type="submit"
              size="lg"
              className="text-lg px-12 h-14"
              disabled={searchMutation.isPending}
              data-testid="button-submit-search"
            >
              {searchMutation.isPending ? (
                <>
                  <div className="animate-spin w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full mr-2" />
                  Searching...
                </>
              ) : (
                <>
                  <SearchIcon className="w-5 h-5 mr-2" />
                  Start Search
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
