import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  ChevronLeft,
  Search as SearchIcon,
  History,
  Settings,
  Clock,
  CheckCircle2,
  XCircle,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import type { Search } from "@shared/schema";

export default function Profile() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch all searches
  const { data: searches = [], isLoading: isLoadingSearches } = useQuery<Search[]>({
    queryKey: ["/api/searches"],
    enabled: isAuthenticated,
  });

  const getInitials = () => {
    if (!user) return "U";
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.email) {
      return user.email.substring(0, 2).toUpperCase();
    }
    return "U";
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const usagePercentage = (user.searchesTotal ?? 3) > 0 
    ? (((user.searchesTotal ?? 3) - (user.searchesRemaining ?? 3)) / (user.searchesTotal ?? 3)) * 100 
    : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <SearchIcon className="w-5 h-5 text-primary" />
              </div>
              <span className="text-xl font-bold">NameCheck</span>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.location.href = "/api/logout"}
            data-testid="button-logout"
          >
            Sign Out
          </Button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Profile Header */}
        <div className="flex flex-col md:flex-row gap-6 items-start md:items-center mb-12">
          <Avatar className="w-24 h-24">
            <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} className="object-cover" />
            <AvatarFallback className="text-2xl">{getInitials()}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2" data-testid="text-user-name">
              {user.firstName && user.lastName
                ? `${user.firstName} ${user.lastName}`
                : user.email}
            </h1>
            <p className="text-muted-foreground mb-4" data-testid="text-user-email">
              {user.email}
            </p>
            <div className="flex flex-wrap gap-3">
              <Badge variant="secondary" className="capitalize" data-testid="badge-plan">
                <Sparkles className="w-3 h-3 mr-1" />
                {user.subscriptionTier || "Free"} Plan
              </Badge>
              <Badge variant="secondary" data-testid="badge-member-since">
                <Clock className="w-3 h-3 mr-1" />
                Member since {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "Unknown"}
              </Badge>
            </div>
          </div>
          <Button
            onClick={() => setLocation("/subscription")}
            data-testid="button-manage-subscription"
          >
            Manage Subscription
          </Button>
        </div>

        <Tabs defaultValue="history" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="history" data-testid="tab-history">
              <History className="w-4 h-4 mr-2" />
              Search History
            </TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">
              <Settings className="w-4 h-4 mr-2" />
              Account Settings
            </TabsTrigger>
          </TabsList>

          {/* Search History Tab */}
          <TabsContent value="history" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-6">Search History</h2>
              
              {isLoadingSearches ? (
                <div className="flex justify-center py-12">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                </div>
              ) : searches.length === 0 ? (
                <div className="text-center py-12">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-muted mb-4">
                    <SearchIcon className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2" data-testid="text-no-history">
                    No search history
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    Your completed searches will appear here
                  </p>
                  <Button onClick={() => setLocation("/search")} data-testid="button-create-search">
                    Create Your First Search
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {searches.map((search) => (
                    <Card
                      key={search.id}
                      className="p-4 hover-elevate cursor-pointer transition-all"
                      onClick={() => setLocation(`/results/${search.id}`)}
                      data-testid={`card-history-${search.id}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold" data-testid={`text-history-term-${search.id}`}>
                              {search.searchTerm}
                            </h3>
                            {search.status === "completed" && search.overallScore !== null && (
                              <Badge
                                variant={
                                  search.overallScore >= 70
                                    ? "default"
                                    : search.overallScore >= 40
                                    ? "secondary"
                                    : "destructive"
                                }
                                className={
                                  search.overallScore >= 70
                                    ? "bg-chart-3 hover:bg-chart-3"
                                    : search.overallScore >= 40
                                    ? "bg-chart-4 hover:bg-chart-4"
                                    : ""
                                }
                                data-testid={`badge-history-score-${search.id}`}
                              >
                                {search.overallScore}% Available
                              </Badge>
                            )}
                            {search.status === "processing" && (
                              <Badge variant="secondary" data-testid={`badge-history-status-${search.id}`}>
                                <Clock className="w-3 h-3 mr-1" />
                                Processing
                              </Badge>
                            )}
                            {search.status === "failed" && (
                              <Badge variant="destructive" data-testid={`badge-history-status-${search.id}`}>
                                <XCircle className="w-3 h-3 mr-1" />
                                Failed
                              </Badge>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {search.createdAt ? new Date(search.createdAt).toLocaleDateString() : "Unknown"} at{" "}
                              {search.createdAt ? new Date(search.createdAt).toLocaleTimeString() : "Unknown"}
                            </span>
                            <span>•</span>
                            <span>{search.jurisdictions.join(", ")}</span>
                            <span>•</span>
                            <span className="capitalize">{search.checkTypes.join(", ")}</span>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-muted-foreground" />
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            {/* Usage Stats */}
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-6">Usage Statistics</h2>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Searches This Month</span>
                    <span className="text-2xl font-bold" data-testid="text-settings-searches">
                      {(user.searchesTotal ?? 3) - (user.searchesRemaining ?? 3)} / {user.searchesTotal ?? 3}
                    </span>
                  </div>
                  <Progress value={usagePercentage} className="h-2 mb-2" />
                  <p className="text-sm text-muted-foreground">
                    {user.searchesRemaining ?? 0} searches remaining
                  </p>
                </div>

                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Need More Searches?</h3>
                      <p className="text-sm text-muted-foreground mb-3">
                        Upgrade your plan to get more searches and unlock advanced features
                      </p>
                      <Button
                        size="sm"
                        onClick={() => setLocation("/subscription")}
                        data-testid="button-upgrade-plan"
                      >
                        Upgrade Plan
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Account Info */}
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-6">Account Information</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Email</label>
                  <p className="text-lg" data-testid="text-settings-email">{user.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Name</label>
                  <p className="text-lg" data-testid="text-settings-name">
                    {user.firstName && user.lastName
                      ? `${user.firstName} ${user.lastName}`
                      : "Not set"}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Current Plan
                  </label>
                  <p className="text-lg capitalize" data-testid="text-settings-plan">
                    {user.subscriptionTier || "Free"}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">
                    Member Since
                  </label>
                  <p className="text-lg" data-testid="text-settings-joined">
                    {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "Unknown"}
                  </p>
                </div>
              </div>
            </Card>

            {/* Danger Zone */}
            <Card className="p-6 border-destructive/50">
              <h2 className="text-2xl font-bold mb-4 text-destructive">Danger Zone</h2>
              <p className="text-muted-foreground mb-4">
                Once you delete your account, there is no going back. Please be certain.
              </p>
              <Button variant="destructive" data-testid="button-delete-account">
                Delete Account
              </Button>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
