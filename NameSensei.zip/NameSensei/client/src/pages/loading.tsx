import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Loader2 } from "lucide-react";

interface LoadingProps {
  searchTerm: string;
  jurisdictions: string[];
  checkTypes: string[];
}

export default function Loading({ searchTerm, jurisdictions, checkTypes }: LoadingProps) {
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    { label: "Checking domain availability", duration: 2000 },
    { label: "Scanning social media platforms", duration: 2500 },
    { label: "Searching trademark databases", duration: 3000 },
    { label: "Analyzing results", duration: 1500 },
  ];

  useEffect(() => {
    const totalDuration = steps.reduce((acc, step) => acc + step.duration, 0);
    let elapsed = 0;

    const interval = setInterval(() => {
      elapsed += 100;
      const newProgress = Math.min((elapsed / totalDuration) * 100, 95);
      setProgress(newProgress);

      let accumulatedDuration = 0;
      for (let i = 0; i < steps.length; i++) {
        accumulatedDuration += steps[i].duration;
        if (elapsed < accumulatedDuration) {
          setCurrentStep(i);
          break;
        }
      }

      if (elapsed >= totalDuration) {
        clearInterval(interval);
      }
    }, 100);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 mb-2">
          <Loader2 className="w-10 h-10 text-primary animate-spin" />
        </div>
        <h1 className="text-3xl font-bold" data-testid="text-loading-title">
          Searching "{searchTerm}"
        </h1>
        <p className="text-lg text-muted-foreground">
          Checking availability across {jurisdictions.join(", ")}
        </p>
      </div>

      {/* Progress Card */}
      <Card className="p-8">
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Steps */}
          <div className="space-y-4">
            {steps.map((step, index) => (
              <div
                key={index}
                className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                  index === currentStep
                    ? "bg-primary/5 border border-primary/20"
                    : index < currentStep
                    ? "bg-muted/50"
                    : "opacity-50"
                }`}
                data-testid={`step-${index}`}
              >
                {index < currentStep ? (
                  <CheckCircle2 className="w-5 h-5 text-chart-3 flex-shrink-0" />
                ) : index === currentStep ? (
                  <Loader2 className="w-5 h-5 text-primary animate-spin flex-shrink-0" />
                ) : (
                  <div className="w-5 h-5 rounded-full border-2 border-border flex-shrink-0" />
                )}
                <span className={`${index === currentStep ? "font-medium" : ""}`}>
                  {step.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Check Types */}
      <div className="flex flex-wrap justify-center gap-2">
        {checkTypes.map((type) => (
          <Badge key={type} variant="secondary" className="capitalize">
            {type}
          </Badge>
        ))}
      </div>
    </div>
  );
}
