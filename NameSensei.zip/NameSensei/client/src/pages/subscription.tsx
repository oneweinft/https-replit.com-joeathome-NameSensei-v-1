import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  CheckCircle2,
  ChevronLeft,
  Search as SearchIcon,
  Sparkles,
  Zap,
  Crown,
} from "lucide-react";

export default function Subscription() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const plans = [
    {
      id: "free",
      name: "Free",
      price: 0,
      searches: 3,
      icon: SearchIcon,
      features: [
        "3 searches per month",
        "Basic domain checks",
        "Social media availability",
        "Email support",
      ],
      color: "text-muted-foreground",
      bgColor: "bg-muted/50",
    },
    {
      id: "basic",
      name: "Basic",
      price: 19,
      searches: 25,
      icon: Zap,
      popular: true,
      features: [
        "25 searches per month",
        "All domain extensions",
        "Social media availability",
        "Trademark database access",
        "Priority email support",
        "Export results to PDF",
      ],
      color: "text-primary",
      bgColor: "bg-primary/5",
    },
    {
      id: "pro",
      name: "Pro",
      price: 49,
      searches: 100,
      icon: Crown,
      features: [
        "100 searches per month",
        "All domain extensions",
        "Social media availability",
        "Trademark database access",
        "API access",
        "Priority support (24/7)",
        "Advanced analytics",
        "Bulk search import",
      ],
      color: "text-chart-4",
      bgColor: "bg-chart-4/5",
    },
  ];

  const getInitials = () => {
    if (!user) return "U";
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.email) {
      return user.email.substring(0, 2).toUpperCase();
    }
    return "U";
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <SearchIcon className="w-5 h-5 text-primary" />
              </div>
              <span className="text-xl font-bold">NameCheck</span>
            </div>
          </div>
          <Button
            variant="ghost"
            onClick={() => setLocation("/profile")}
            data-testid="button-profile"
          >
            <Avatar className="w-8 h-8 mr-2">
              <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} className="object-cover" />
              <AvatarFallback>{getInitials()}</AvatarFallback>
            </Avatar>
            <span className="hidden sm:inline">{user.firstName || user.email}</span>
          </Button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4" data-testid="badge-current-plan">
            Current plan: {user.subscriptionTier || "Free"}
          </Badge>
          <h1 className="text-4xl font-bold mb-4" data-testid="text-page-title">
            Choose Your Plan
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Upgrade to unlock more searches and advanced features
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const isCurrentPlan = (user.subscriptionTier || "free") === plan.id;

            return (
              <Card
                key={plan.id}
                className={`p-8 relative ${
                  plan.popular
                    ? "border-primary border-2 shadow-lg"
                    : ""
                }`}
              >
                {plan.popular && (
                  <Badge
                    className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary"
                    data-testid="badge-popular"
                  >
                    <Sparkles className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                )}

                <div className={`w-12 h-12 rounded-xl ${plan.bgColor} flex items-center justify-center mb-4`}>
                  <Icon className={`w-6 h-6 ${plan.color}`} />
                </div>

                <h3 className="text-2xl font-bold mb-2" data-testid={`text-plan-${plan.id}`}>
                  {plan.name}
                </h3>

                <div className="mb-6">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-muted-foreground">/month</span>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle2 className="w-5 h-5 text-chart-3 flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className="w-full"
                  variant={plan.popular ? "default" : "outline"}
                  size="lg"
                  disabled={isCurrentPlan}
                  onClick={() => {
                    if (plan.id === "free") {
                      toast({
                        title: "Free Plan",
                        description: "You're already on the free plan",
                      });
                    } else {
                      setLocation(`/checkout?plan=${plan.id}`);
                    }
                  }}
                  data-testid={`button-select-${plan.id}`}
                >
                  {isCurrentPlan ? "Current Plan" : plan.price === 0 ? "Get Started" : "Upgrade Now"}
                </Button>
              </Card>
            );
          })}
        </div>

        {/* FAQ or Features Comparison */}
        <Card className="p-8 bg-gradient-to-br from-primary/5 to-accent/5">
          <h2 className="text-2xl font-bold mb-6 text-center">Why Upgrade?</h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">More Searches</h3>
                <p className="text-sm text-muted-foreground">
                  Run more searches each month to explore all your brand ideas
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Comprehensive Data</h3>
                <p className="text-sm text-muted-foreground">
                  Access full trademark databases and advanced domain information
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Priority Support</h3>
                <p className="text-sm text-muted-foreground">
                  Get help when you need it with our dedicated support team
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Advanced Features</h3>
                <p className="text-sm text-muted-foreground">
                  Export reports, API access, and bulk search capabilities
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
