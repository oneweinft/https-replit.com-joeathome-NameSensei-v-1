import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle2, 
  Globe, 
  Search, 
  Shield, 
  Zap,
  ArrowRight,
  Instagram,
  Linkedin,
} from "lucide-react";
import { SiX, SiFacebook } from "react-icons/si";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Search className="w-5 h-5 text-primary" />
            </div>
            <span className="text-xl font-bold" data-testid="text-logo">NameCheck</span>
          </div>
          <Button 
            onClick={() => window.location.href = "/api/login"}
            data-testid="button-login"
          >
            Sign In
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 pointer-events-none" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="text-center space-y-8 max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-4" data-testid="badge-new">
              <Zap className="w-3 h-3 mr-1" />
              Now supporting 3 major regions
            </Badge>
            
            <h1 className="text-5xl lg:text-6xl font-bold tracking-tight" data-testid="text-hero-title">
              Find the Perfect Name
              <br />
              <span className="text-primary">for Your Business</span>
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-hero-description">
              Check domain, social media, and trademark availability across Australasia, Europe, and USA — all in one comprehensive search.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <Button 
                size="lg" 
                className="text-lg px-8 h-12"
                onClick={() => window.location.href = "/api/login"}
                data-testid="button-start-searching"
              >
                Start Searching
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="text-lg px-8 h-12"
                data-testid="button-learn-more"
              >
                Learn More
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap items-center justify-center gap-8 pt-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-chart-3" />
                <span>Instant Results</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-chart-3" />
                <span>Secure & Private</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-chart-3" />
                <span>Global Coverage</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4" data-testid="text-features-title">
              Everything You Need in One Search
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our comprehensive platform checks all the crucial aspects of your business name availability
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Domain Check */}
            <Card className="p-6 hover-elevate transition-all">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Globe className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3" data-testid="text-feature-domain">Domain Names</h3>
              <p className="text-muted-foreground mb-4">
                Check availability for .com, .au, .eu, .us and other major domain extensions
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">.com</Badge>
                <Badge variant="secondary">.au</Badge>
                <Badge variant="secondary">.eu</Badge>
                <Badge variant="secondary">.us</Badge>
              </div>
            </Card>

            {/* Social Media Check */}
            <Card className="p-6 hover-elevate transition-all">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <SiX className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3" data-testid="text-feature-social">Social Media</h3>
              <p className="text-muted-foreground mb-4">
                Verify username availability across major social platforms
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="gap-1">
                  <SiX className="w-3 h-3" />
                  X
                </Badge>
                <Badge variant="secondary" className="gap-1">
                  <Instagram className="w-3 h-3" />
                  Instagram
                </Badge>
                <Badge variant="secondary" className="gap-1">
                  <SiFacebook className="w-3 h-3" />
                  Facebook
                </Badge>
                <Badge variant="secondary" className="gap-1">
                  <Linkedin className="w-3 h-3" />
                  LinkedIn
                </Badge>
              </div>
            </Card>

            {/* Trademark Check */}
            <Card className="p-6 hover-elevate transition-all">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3" data-testid="text-feature-trademark">Trademarks</h3>
              <p className="text-muted-foreground mb-4">
                Search official trademark databases for potential conflicts
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">IP Australia</Badge>
                <Badge variant="secondary">EUIPO</Badge>
                <Badge variant="secondary">USPTO</Badge>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Card className="p-12 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4" data-testid="text-cta-title">
              Ready to Find Your Perfect Name?
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of entrepreneurs who trust NameCheck to validate their business names
            </p>
            <Button 
              size="lg"
              className="text-lg px-8 h-12"
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-get-started-cta"
            >
              Get Started for Free
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-muted-foreground">
            <p>© 2024 NameCheck. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
