import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Globe, Sparkles, TrendingUp } from "lucide-react";

export default function Splash() {
  const [, setLocation] = useLocation();
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      icon: Globe,
      title: "Search Globally",
      description: "Check name availability across Australasia, Europe, and USA in one search"
    },
    {
      icon: CheckCircle2,
      title: "Comprehensive Checks",
      description: "Verify domains, social media handles, and trademark registrations instantly"
    },
    {
      icon: TrendingUp,
      title: "Start Your Business",
      description: "Get detailed insights to confidently launch your brand worldwide"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center space-y-8">
        {/* Logo/Brand */}
        <div className="space-y-4">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 border border-primary/20 mb-4">
            <Sparkles className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-5xl font-bold tracking-tight" data-testid="text-app-title">
            NameCheck
          </h1>
          <p className="text-xl text-muted-foreground">
            Professional Business Name Search Platform
          </p>
        </div>

        {/* Onboarding Slides */}
        <div className="bg-card border border-card-border rounded-2xl p-8 min-h-[280px] flex flex-col items-center justify-center space-y-6">
          {slides.map((slide, index) => {
            const Icon = slide.icon;
            return (
              <div
                key={index}
                className={`transition-all duration-500 ${
                  index === currentSlide
                    ? "opacity-100 scale-100"
                    : "opacity-0 scale-95 absolute"
                }`}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-primary/10 mb-4">
                  <Icon className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold mb-3">{slide.title}</h2>
                <p className="text-muted-foreground text-lg max-w-md mx-auto">
                  {slide.description}
                </p>
              </div>
            );
          })}

          {/* Slide Indicators */}
          <div className="flex gap-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2 rounded-full transition-all ${
                  index === currentSlide
                    ? "w-8 bg-primary"
                    : "w-2 bg-border hover-elevate"
                }`}
                data-testid={`button-slide-${index}`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* CTA Button */}
        <Button
          size="lg"
          className="text-lg px-8 py-6 h-auto"
          onClick={() => setLocation("/")}
          data-testid="button-get-started"
        >
          Get Started
        </Button>
      </div>
    </div>
  );
}
