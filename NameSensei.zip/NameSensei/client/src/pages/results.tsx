import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ChevronLeft,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ExternalLink,
  Download,
  Search as SearchIcon,
} from "lucide-react";
import type { Search } from "@shared/schema";
import Loading from "./loading";

export default function Results() {
  const params = useParams();
  const searchId = params.id;
  const { user, isLoading: isAuthLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isAuthLoading, toast]);

  const { data: search, isLoading: isLoadingSearch } = useQuery<Search>({
    queryKey: ["/api/searches", searchId],
    enabled: isAuthenticated && !!searchId,
    refetchInterval: (query) => {
      const data = query.state.data;
      return data?.status === "processing" || data?.status === "pending" ? 2000 : false;
    },
  });

  const getInitials = () => {
    if (!user) return "U";
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.email) {
      return user.email.substring(0, 2).toUpperCase();
    }
    return "U";
  };

  if (isAuthLoading || !user || isLoadingSearch) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!search) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <h2 className="text-xl font-semibold mb-2">Search Not Found</h2>
          <p className="text-muted-foreground mb-4">
            This search doesn't exist or you don't have permission to view it.
          </p>
          <Button onClick={() => setLocation("/")}>Go to Dashboard</Button>
        </Card>
      </div>
    );
  }

  if (search.status === "processing" || search.status === "pending") {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur-sm z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/")}
                data-testid="button-back"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <SearchIcon className="w-5 h-5 text-primary" />
                </div>
                <span className="text-xl font-bold">NameCheck</span>
              </div>
            </div>
            <Button
              variant="ghost"
              onClick={() => setLocation("/profile")}
              data-testid="button-profile"
            >
              <Avatar className="w-8 h-8 mr-2">
                <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} className="object-cover" />
                <AvatarFallback>{getInitials()}</AvatarFallback>
              </Avatar>
              <span className="hidden sm:inline">{user.firstName || user.email}</span>
            </Button>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Loading
            searchTerm={search.searchTerm}
            jurisdictions={search.jurisdictions}
            checkTypes={search.checkTypes}
          />
        </div>
      </div>
    );
  }

  const domainResults = (search.domainResults as any) || {};
  const socialResults = (search.socialResults as any) || {};
  const trademarkResults = (search.trademarkResults as any) || {};

  const getScoreColor = (score: number | null) => {
    if (score === null) return "text-muted-foreground";
    if (score >= 70) return "text-chart-3";
    if (score >= 40) return "text-chart-4";
    return "text-destructive";
  };

  const getScoreBg = (score: number | null) => {
    if (score === null) return "bg-muted";
    if (score >= 70) return "bg-chart-3";
    if (score >= 40) return "bg-chart-4";
    return "bg-destructive";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              data-testid="button-back"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <SearchIcon className="w-5 h-5 text-primary" />
              </div>
              <span className="text-xl font-bold">NameCheck</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              data-testid="button-export"
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Button
              variant="ghost"
              onClick={() => setLocation("/profile")}
              data-testid="button-profile"
            >
              <Avatar className="w-8 h-8 mr-2">
                <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} className="object-cover" />
                <AvatarFallback>{getInitials()}</AvatarFallback>
              </Avatar>
              <span className="hidden sm:inline">{user.firstName || user.email}</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Results Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4" data-testid="text-search-term">
            "{search.searchTerm}"
          </h1>
          <p className="text-lg text-muted-foreground">
            Checked across {search.jurisdictions.join(", ")}
          </p>
        </div>

        {/* Overall Score */}
        <Card className="p-8 mb-12 text-center bg-gradient-to-br from-primary/5 to-accent/5">
          <div className="max-w-md mx-auto">
            <p className="text-sm font-medium text-muted-foreground mb-4">
              Overall Availability Score
            </p>
            <div className="relative inline-flex items-center justify-center w-40 h-40 mb-6">
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="12"
                  className="text-muted"
                />
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="12"
                  strokeDasharray={`${2 * Math.PI * 70}`}
                  strokeDashoffset={`${
                    2 * Math.PI * 70 * (1 - (search.overallScore || 0) / 100)
                  }`}
                  className={getScoreColor(search.overallScore)}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span
                  className={`text-5xl font-bold ${getScoreColor(search.overallScore)}`}
                  data-testid="text-overall-score"
                >
                  {search.overallScore || 0}%
                </span>
              </div>
            </div>
            <p className="text-lg font-medium">
              {search.overallScore && search.overallScore >= 70
                ? "Great! This name is mostly available"
                : search.overallScore && search.overallScore >= 40
                ? "Partially available - review details"
                : "Limited availability - consider alternatives"}
            </p>
          </div>
        </Card>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {search.checkTypes.includes("domain") && (
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                Domain Names
                <Badge variant="secondary" className="ml-auto">
                  {Object.keys(domainResults).length}
                </Badge>
              </h3>
              <div className="space-y-2">
                {Object.entries(domainResults).map(([domain, data]: [string, any]) => (
                  <div
                    key={domain}
                    className="flex items-center justify-between p-2 rounded hover-elevate"
                  >
                    <span className="font-mono text-sm">.{domain}</span>
                    {data.available ? (
                      <CheckCircle2 className="w-4 h-4 text-chart-3" />
                    ) : (
                      <XCircle className="w-4 h-4 text-destructive" />
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {search.checkTypes.includes("social") && (
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                Social Media
                <Badge variant="secondary" className="ml-auto">
                  {Object.keys(socialResults).length}
                </Badge>
              </h3>
              <div className="space-y-2">
                {Object.entries(socialResults).map(([platform, data]: [string, any]) => (
                  <div
                    key={platform}
                    className="flex items-center justify-between p-2 rounded hover-elevate"
                  >
                    <span className="capitalize text-sm">{platform}</span>
                    {data.available ? (
                      <CheckCircle2 className="w-4 h-4 text-chart-3" />
                    ) : (
                      <XCircle className="w-4 h-4 text-destructive" />
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {search.checkTypes.includes("trademark") && (
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                Trademarks
                <Badge variant="secondary" className="ml-auto">
                  {Object.keys(trademarkResults).length}
                </Badge>
              </h3>
              <div className="space-y-2">
                {Object.entries(trademarkResults).map(([region, data]: [string, any]) => {
                  const conflicts = Array.isArray(data) ? data.length : 0;
                  return (
                    <div
                      key={region}
                      className="flex items-center justify-between p-2 rounded hover-elevate"
                    >
                      <span className="capitalize text-sm">{region}</span>
                      {conflicts === 0 ? (
                        <CheckCircle2 className="w-4 h-4 text-chart-3" />
                      ) : (
                        <Badge variant="destructive" className="text-xs">
                          {conflicts} conflict{conflicts > 1 ? "s" : ""}
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            </Card>
          )}
        </div>

        {/* Detailed Results Tabs */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold mb-6">Detailed Results</h2>
          <Tabs defaultValue="domain" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="domain" data-testid="tab-domain">
                Domains
              </TabsTrigger>
              <TabsTrigger value="social" data-testid="tab-social">
                Social Media
              </TabsTrigger>
              <TabsTrigger value="trademark" data-testid="tab-trademark">
                Trademarks
              </TabsTrigger>
            </TabsList>

            <TabsContent value="domain" className="space-y-4">
              {Object.entries(domainResults).map(([domain, data]: [string, any]) => (
                <Card key={domain} className="p-4 border-l-4" style={{
                  borderLeftColor: data.available ? "hsl(var(--chart-3))" : "hsl(var(--destructive))"
                }}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold font-mono" data-testid={`domain-${domain}`}>
                          {search.searchTerm}.{domain}
                        </h3>
                        <Badge
                          variant={data.available ? "default" : "destructive"}
                          className={data.available ? "bg-chart-3 hover:bg-chart-3" : ""}
                        >
                          {data.available ? "Available" : "Taken"}
                        </Badge>
                      </div>
                      {data.registrar && (
                        <p className="text-sm text-muted-foreground">
                          Registrar: {data.registrar}
                        </p>
                      )}
                      {data.price && (
                        <p className="text-sm text-muted-foreground">
                          Estimated price: ${data.price}/year
                        </p>
                      )}
                    </div>
                    {data.available && (
                      <Button variant="outline" size="sm">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Register
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="social" className="space-y-4">
              {Object.entries(socialResults).map(([platform, data]: [string, any]) => (
                <Card key={platform} className="p-4 border-l-4" style={{
                  borderLeftColor: data.available ? "hsl(var(--chart-3))" : "hsl(var(--destructive))"
                }}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold capitalize" data-testid={`social-${platform}`}>
                          {platform}
                        </h3>
                        <Badge
                          variant={data.available ? "default" : "destructive"}
                          className={data.available ? "bg-chart-3 hover:bg-chart-3" : ""}
                        >
                          {data.available ? "Available" : "Taken"}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground font-mono">
                        @{data.username || search.searchTerm.toLowerCase().replace(/\s+/g, "")}
                      </p>
                    </div>
                    {data.url && (
                      <Button variant="outline" size="sm" asChild>
                        <a href={data.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View
                        </a>
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="trademark" className="space-y-4">
              {Object.entries(trademarkResults).map(([region, conflicts]: [string, any]) => {
                const conflictArray = Array.isArray(conflicts) ? conflicts : [];
                return (
                  <Card key={region} className="p-4 border-l-4" style={{
                    borderLeftColor: conflictArray.length === 0 ? "hsl(var(--chart-3))" : "hsl(var(--destructive))"
                  }}>
                    <div className="mb-3">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold capitalize" data-testid={`trademark-${region}`}>
                          {region}
                        </h3>
                        <Badge
                          variant={conflictArray.length === 0 ? "default" : "destructive"}
                          className={conflictArray.length === 0 ? "bg-chart-3 hover:bg-chart-3" : ""}
                        >
                          {conflictArray.length === 0
                            ? "No conflicts found"
                            : `${conflictArray.length} conflict${conflictArray.length > 1 ? "s" : ""}`}
                        </Badge>
                      </div>
                    </div>
                    {conflictArray.length > 0 && (
                      <div className="space-y-3 mt-4">
                        {conflictArray.map((conflict: any, index: number) => (
                          <div
                            key={index}
                            className="p-3 bg-muted/50 rounded-lg border border-border"
                          >
                            <div className="flex items-start gap-2">
                              <AlertCircle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                              <div className="flex-1">
                                <p className="font-medium">{conflict.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  Status: {conflict.status}
                                </p>
                                {conflict.registrationNumber && (
                                  <p className="text-sm text-muted-foreground font-mono">
                                    #{conflict.registrationNumber}
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </Card>
                );
              })}
            </TabsContent>
          </Tabs>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-center gap-4 mt-12">
          <Button
            variant="outline"
            size="lg"
            onClick={() => setLocation("/search")}
            data-testid="button-new-search"
          >
            New Search
          </Button>
          <Button
            size="lg"
            onClick={() => setLocation("/")}
            data-testid="button-dashboard"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
}
