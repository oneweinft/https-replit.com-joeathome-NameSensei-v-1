import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Search,
  History,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import type { Search as SearchType } from "@shared/schema";

export default function Dashboard() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch recent searches
  const { data: recentSearches = [], isLoading: isLoadingSearches } = useQuery<SearchType[]>({
    queryKey: ["/api/searches/recent"],
    enabled: isAuthenticated,
  });

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const usagePercentage = (user.searchesTotal ?? 3) > 0 
    ? (((user.searchesTotal ?? 3) - (user.searchesRemaining ?? 3)) / (user.searchesTotal ?? 3)) * 100 
    : 0;

  const getInitials = () => {
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.email) {
      return user.email.substring(0, 2).toUpperCase();
    }
    return "U";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Search className="w-5 h-5 text-primary" />
            </div>
            <span className="text-xl font-bold">NameCheck</span>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => setLocation("/profile")}
              data-testid="button-profile"
            >
              <Avatar className="w-8 h-8 mr-2">
                <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} className="object-cover" />
                <AvatarFallback>{getInitials()}</AvatarFallback>
              </Avatar>
              <span className="hidden sm:inline">{user.firstName || user.email}</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.location.href = "/api/logout"}
              data-testid="button-logout"
            >
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-2" data-testid="text-welcome">
            Welcome back, {user.firstName || "there"}!
          </h1>
          <p className="text-lg text-muted-foreground">
            Ready to find the perfect name for your business?
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {/* Usage Card */}
          <Card className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Searches Remaining</p>
                <p className="text-3xl font-bold" data-testid="text-searches-remaining">
                  {user.searchesRemaining ?? 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Search className="w-6 h-6 text-primary" />
              </div>
            </div>
            <Progress value={usagePercentage} className="mb-2" />
            <p className="text-xs text-muted-foreground">
              {(user.searchesTotal ?? 3) - (user.searchesRemaining ?? 3)} of {user.searchesTotal ?? 3} used
            </p>
          </Card>

          {/* Subscription Card */}
          <Card className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Current Plan</p>
                <p className="text-2xl font-bold capitalize" data-testid="text-subscription-tier">
                  {user.subscriptionTier || "Free"}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-chart-3" />
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => setLocation("/subscription")}
              data-testid="button-upgrade"
            >
              Upgrade Plan
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Card>

          {/* Recent Activity Card */}
          <Card className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Searches</p>
                <p className="text-3xl font-bold" data-testid="text-total-searches">
                  {recentSearches.length}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-chart-2" />
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => setLocation("/profile")}
              data-testid="button-view-history"
            >
              View History
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </Card>
        </div>

        {/* Quick Search Section */}
        <Card className="p-8 mb-12 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <div className="text-center max-w-2xl mx-auto space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-2">
              <Search className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-3xl font-bold" data-testid="text-start-search">
              Start a New Search
            </h2>
            <p className="text-lg text-muted-foreground">
              Check if your business name is available across domains, social media, and trademarks
            </p>
            <Button
              size="lg"
              className="text-lg px-8 h-12"
              onClick={() => setLocation("/search")}
              data-testid="button-new-search"
            >
              Search Now
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </Card>

        {/* Recent Searches */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <History className="w-6 h-6" />
              Recent Searches
            </h2>
          </div>

          {isLoadingSearches ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
            </div>
          ) : recentSearches.length === 0 ? (
            <Card className="p-12 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-muted mb-4">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2" data-testid="text-no-searches">
                No searches yet
              </h3>
              <p className="text-muted-foreground mb-6">
                Start your first search to see results here
              </p>
              <Button onClick={() => setLocation("/search")} data-testid="button-first-search">
                Create Your First Search
              </Button>
            </Card>
          ) : (
            <div className="space-y-4">
              {recentSearches.slice(0, 5).map((search) => (
                <Card
                  key={search.id}
                  className="p-4 hover-elevate cursor-pointer transition-all"
                  onClick={() => setLocation(`/results/${search.id}`)}
                  data-testid={`card-search-${search.id}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold" data-testid={`text-search-term-${search.id}`}>
                          {search.searchTerm}
                        </h3>
                        {search.status === "completed" && search.overallScore !== null && (
                          <Badge
                            variant={
                              search.overallScore >= 70
                                ? "default"
                                : search.overallScore >= 40
                                ? "secondary"
                                : "destructive"
                            }
                            className={
                              search.overallScore >= 70
                                ? "bg-chart-3 hover:bg-chart-3"
                                : search.overallScore >= 40
                                ? "bg-chart-4 hover:bg-chart-4"
                                : ""
                            }
                            data-testid={`badge-score-${search.id}`}
                          >
                            {search.overallScore}% Available
                          </Badge>
                        )}
                        {search.status === "processing" && (
                          <Badge variant="secondary" data-testid={`badge-status-${search.id}`}>
                            <Clock className="w-3 h-3 mr-1" />
                            Processing
                          </Badge>
                        )}
                        {search.status === "failed" && (
                          <Badge variant="destructive" data-testid={`badge-status-${search.id}`}>
                            <XCircle className="w-3 h-3 mr-1" />
                            Failed
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {search.createdAt ? new Date(search.createdAt).toLocaleDateString() : "Unknown"}
                        </span>
                        <span>•</span>
                        <span>{search.jurisdictions.join(", ")}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
