# Design Guidelines: Business Name Search Platform

## Design Approach

**Selected Approach:** Design System-Inspired (Modern SaaS)
**Reference Inspiration:** Linear, Stripe, Notion
**Rationale:** Utility-focused business tool requiring clarity, professionalism, and efficient data presentation

**Core Principles:**
- Clarity over decoration
- Information hierarchy through typography and spacing
- Professional credibility
- Efficient user flows
- Data-first presentation

---

## Color Palette

**Dark Mode (Primary)**
- Background: 222 15% 8%
- Surface: 222 15% 12%
- Surface Elevated: 222 15% 16%
- Border: 222 12% 24%
- Text Primary: 0 0% 98%
- Text Secondary: 0 0% 70%
- Text Muted: 0 0% 50%

**Brand Colors**
- Primary: 262 90% 65% (vibrant purple - CTA, active states)
- Primary Hover: 262 90% 70%
- Success: 142 76% 36% (available status)
- Warning: 38 92% 50% (partial availability)
- Error: 0 84% 60% (unavailable status)
- Info: 217 91% 60% (informational badges)

**Light Mode**
- Background: 0 0% 100%
- Surface: 0 0% 98%
- Surface Elevated: 0 0% 100%
- Border: 220 13% 91%
- Text Primary: 222 47% 11%
- Text Secondary: 215 16% 47%
- Text Muted: 215 14% 64%

---

## Typography

**Font Family**
- Primary: 'Inter', system-ui, sans-serif (via Google Fonts CDN)
- Monospace: 'JetBrains Mono', monospace (for domain names, codes)

**Scale**
- Headline Large: 3xl (48px), font-bold, tracking-tight
- Headline: 2xl (32px), font-semibold, tracking-tight
- Title: xl (24px), font-semibold
- Subtitle: lg (20px), font-medium
- Body: base (16px), font-normal
- Body Small: sm (14px), font-normal
- Caption: xs (12px), font-normal, text-muted

**Line Heights**
- Tight: leading-tight (headlines)
- Normal: leading-normal (body text)
- Relaxed: leading-relaxed (long-form content)

---

## Layout System

**Spacing Primitives**
- Core units: 2, 4, 6, 8, 12, 16, 24
- Section padding: py-16 lg:py-24
- Component spacing: space-y-6 to space-y-8
- Card padding: p-6 lg:p-8
- Micro spacing: gap-2, gap-4

**Container Widths**
- Full app: max-w-7xl mx-auto px-4
- Content sections: max-w-4xl
- Forms: max-w-md
- Modals: max-w-2xl

**Grid System**
- Dashboard cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Results layout: grid-cols-1 lg:grid-cols-2
- Search options: grid-cols-2 md:grid-cols-3

---

## Component Library

### Navigation & Headers
- **Top Navigation:** Fixed header with logo, navigation links, user menu
- Height: h-16
- Backdrop blur with border-b
- Sticky positioning on scroll

### Cards & Surfaces
- **Default Card:** Rounded corners (rounded-xl), subtle border, hover state with slight elevation
- **Result Card:** Border-l-4 with status color (green/yellow/red)
- **Summary Card:** Larger padding, bold metrics, icon integration
- **Evidence Card:** Collapsible sections, monospace for technical data

### Buttons
- **Primary:** bg-primary, white text, rounded-lg, px-6 py-3
- **Secondary:** border, transparent bg, primary text
- **Ghost:** No border, hover bg-surface-elevated
- **Icon Buttons:** Square, p-2, rounded-lg

### Forms
- **Input Fields:** Rounded borders (rounded-lg), focus ring primary color, p-3
- **Labels:** font-medium, text-sm, mb-2
- **Helper Text:** text-xs, text-muted
- **Toggle Switches:** For jurisdiction selection, modern styled

### Status Indicators
- **Badges:** Rounded-full, px-3 py-1, text-xs font-medium
- **Progress Indicators:** Linear progress bars, circular for loading
- **Availability Score:** Large circular gauge (0-100%)

### Data Display
- **Tables:** Striped rows optional, hover states, sticky headers
- **Lists:** Divided, with icons, secondary text
- **Stat Groups:** Grid layout, large numbers, small labels

### Loading States
- **Search Progress:** Multi-step indicator showing current check
- **Skeleton Screens:** Animated pulse for card placeholders
- **Spinner:** Circular, primary color, for inline loading

### Modals & Overlays
- **Modal:** Centered, backdrop blur, rounded-2xl, shadow-2xl
- **Sidebar:** Slide from right for detailed views
- **Toast Notifications:** Bottom-right, auto-dismiss, status colors

---

## Screen-Specific Guidelines

### Splash/Onboarding
- Full-screen centered layout
- Gradient background (subtle purple to blue)
- Large hero headline with animation
- 3-step carousel showing key features
- Clear CTA button

### Dashboard
- Grid layout with usage stats cards
- Recent searches list
- Quick search card (prominent, centered)
- Visual usage gauge/meter
- Empty state for new users

### Search Interface
- Centered search input (prominent, large)
- Jurisdiction toggles below (pill-style)
- Check type selection (grid of checkboxes with icons)
- Preview of what will be searched

### Results Summary
- Large availability score (circular gauge, center-top)
- Status breakdown (grid of cards: domain, social, trademark)
- Color-coded visual hierarchy
- Quick action buttons

### Detailed Evidence
- Tabbed interface (Domain, Social, Trademark)
- Expandable sections per platform
- Monospace for technical details
- Screenshot/proof imagery placeholders
- Export functionality

### Subscription/Pricing
- 3-column pricing tiers
- Feature comparison table
- Highlighted recommended plan
- Usage meter showing current consumption

### Payment (Stripe)
- Clean centered form
- Order summary sidebar
- Trust badges
- Secure payment indicators

### Profile/Settings
- Two-column layout (sidebar nav + content)
- Search history table with filters
- Account settings form
- Usage analytics charts

---

## Animations

**Minimal, Purposeful Only:**
- Page transitions: Fade (200ms)
- Card hover: Subtle lift (transform scale 1.01)
- Button press: Scale 0.98
- Search progress: Smooth progress bar animation
- Modal enter/exit: Slide + fade

---

## Icons

**Library:** Heroicons (via CDN)
- Search: MagnifyingGlassIcon
- Check: CheckCircleIcon
- Warning: ExclamationTriangleIcon
- Error: XCircleIcon
- Loading: ArrowPathIcon (spinning)
- Social platforms: Use FontAwesome brands for logos

---

## Images

**Hero Section (Splash):** Abstract geometric pattern or dashboard preview mockup showcasing the search interface
**Onboarding Slides:** Illustrative graphics showing: 1) Search concept, 2) Multi-jurisdiction checking, 3) Detailed results
**Empty States:** Simple illustrations for no search history, no results

All images should use object-cover, rounded corners, and maintain aspect ratios appropriate to their containers.