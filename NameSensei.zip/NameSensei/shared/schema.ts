import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  
  // Subscription fields
  subscriptionTier: varchar("subscription_tier").default("free"), // free, basic, pro
  searchesRemaining: integer("searches_remaining").default(3),
  searchesTotal: integer("searches_total").default(3),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  
  // Stripe fields
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Searches table - stores all name searches
export const searches = pgTable("searches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  
  // Search parameters
  searchTerm: text("search_term").notNull(),
  jurisdictions: text("jurisdictions").array().notNull(), // ['australasia', 'europe', 'usa']
  checkTypes: text("check_types").array().notNull(), // ['domain', 'social', 'trademark']
  
  // Results
  overallScore: integer("overall_score"), // 0-100
  status: varchar("status").notNull().default("pending"), // pending, processing, completed, failed
  
  // Detailed results as JSON
  domainResults: jsonb("domain_results"), // {com: {available: true}, au: {available: false}, ...}
  socialResults: jsonb("social_results"), // {twitter: {available: true, username: "..."}, ...}
  trademarkResults: jsonb("trademark_results"), // {australasia: [{name: "...", status: "registered"}], ...}
  
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertSearchSchema = createInsertSchema(searches).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export type InsertSearch = z.infer<typeof insertSearchSchema>;
export type Search = typeof searches.$inferSelect;

// Saved searches - for bookmarking favorite searches
export const savedSearches = pgTable("saved_searches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  searchId: varchar("search_id").notNull().references(() => searches.id, { onDelete: "cascade" }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSavedSearchSchema = createInsertSchema(savedSearches).omit({
  id: true,
  createdAt: true,
});

export type InsertSavedSearch = z.infer<typeof insertSavedSearchSchema>;
export type SavedSearch = typeof savedSearches.$inferSelect;
