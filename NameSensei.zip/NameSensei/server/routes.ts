import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import Stripe from "stripe";
import { insertSearchSchema } from "@shared/schema";
import { z } from "zod";

// Initialize Stripe only if the secret key is available
let stripe: Stripe | null = null;
if (process.env.STRIPE_SECRET_KEY) {
  try {
    stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  } catch (error) {
    console.error("Failed to initialize Stripe:", error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Search endpoints
  app.post("/api/searches", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user has searches remaining
      if ((user.searchesRemaining ?? 0) <= 0) {
        return res.status(403).json({ 
          message: "No searches remaining. Please upgrade your plan." 
        });
      }

      // Validate request body
      const validatedData = insertSearchSchema.parse({
        ...req.body,
        userId,
      });

      // Create search
      const search = await storage.createSearch({
        ...validatedData,
        status: "processing",
      });

      // Decrement user's remaining searches
      await storage.upsertUser({
        ...user,
        searchesRemaining: (user.searchesRemaining ?? 3) - 1,
      });

      // Simulate processing (in real app, this would be a background job)
      // For now, we'll process it immediately with mock data
      setTimeout(async () => {
        try {
          const results = generateMockResults(search.searchTerm, search.jurisdictions, search.checkTypes);
          await storage.updateSearch(search.id, {
            status: "completed",
            ...results,
          });
        } catch (error) {
          console.error("Error processing search:", error);
          await storage.updateSearch(search.id, {
            status: "failed",
          });
        }
      }, 5000); // Simulate 5 second processing time

      res.json(search);
    } catch (error: any) {
      console.error("Error creating search:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid search data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create search" });
    }
  });

  app.get("/api/searches/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const search = await storage.getSearch(req.params.id);

      if (!search) {
        return res.status(404).json({ message: "Search not found" });
      }

      // Verify user owns this search
      if (search.userId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      res.json(search);
    } catch (error) {
      console.error("Error fetching search:", error);
      res.status(500).json({ message: "Failed to fetch search" });
    }
  });

  app.get("/api/searches", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const searches = await storage.getUserSearches(userId);
      res.json(searches);
    } catch (error) {
      console.error("Error fetching searches:", error);
      res.status(500).json({ message: "Failed to fetch searches" });
    }
  });

  app.get("/api/searches/recent", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const searches = await storage.getRecentSearches(userId, 5);
      res.json(searches);
    } catch (error) {
      console.error("Error fetching recent searches:", error);
      res.status(500).json({ message: "Failed to fetch recent searches" });
    }
  });

  // Stripe payment endpoints
  app.post("/api/create-payment-intent", isAuthenticated, async (req: any, res) => {
    try {
      if (!stripe) {
        return res.status(503).json({ message: "Payment processing is not configured. Please contact support." });
      }

      const { amount, plan } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }

      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId: req.user.claims.sub,
          plan: plan || "basic",
        },
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to generate mock search results
function generateMockResults(searchTerm: string, jurisdictions: string[], checkTypes: string[]) {
  const results: any = {};
  
  // Calculate overall score
  let availableCount = 0;
  let totalCount = 0;

  // Domain results
  if (checkTypes.includes("domain")) {
    const domainExtensions = ["com", "au", "eu", "us"];
    results.domainResults = {};
    domainExtensions.forEach((ext) => {
      const available = Math.random() > 0.4; // 60% chance of being available
      results.domainResults[ext] = {
        available,
        registrar: available ? null : "GoDaddy",
        price: available ? 12.99 : null,
      };
      totalCount++;
      if (available) availableCount++;
    });
  }

  // Social media results
  if (checkTypes.includes("social")) {
    const platforms = ["twitter", "instagram", "facebook", "linkedin"];
    results.socialResults = {};
    platforms.forEach((platform) => {
      const available = Math.random() > 0.5; // 50% chance of being available
      const username = searchTerm.toLowerCase().replace(/\s+/g, "");
      results.socialResults[platform] = {
        available,
        username,
        url: available ? null : `https://${platform}.com/${username}`,
      };
      totalCount++;
      if (available) availableCount++;
    });
  }

  // Trademark results
  if (checkTypes.includes("trademark")) {
    results.trademarkResults = {};
    jurisdictions.forEach((region) => {
      const numConflicts = Math.floor(Math.random() * 3); // 0-2 conflicts
      const conflicts = [];
      for (let i = 0; i < numConflicts; i++) {
        conflicts.push({
          name: `${searchTerm} ${i + 1}`,
          status: "Registered",
          registrationNumber: `TM${Math.floor(Math.random() * 1000000)}`,
        });
      }
      results.trademarkResults[region] = conflicts;
      totalCount++;
      if (numConflicts === 0) availableCount++;
    });
  }

  // Calculate overall score
  results.overallScore = totalCount > 0 ? Math.round((availableCount / totalCount) * 100) : 0;
  results.completedAt = new Date();

  return results;
}
