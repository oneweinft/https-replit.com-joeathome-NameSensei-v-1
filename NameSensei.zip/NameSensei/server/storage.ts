import {
  users,
  searches,
  savedSearches,
  type User,
  type UpsertUser,
  type Search,
  type InsertSearch,
  type SavedSearch,
  type InsertSavedSearch,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Search operations
  createSearch(search: InsertSearch): Promise<Search>;
  getSearch(id: string): Promise<Search | undefined>;
  getUserSearches(userId: string): Promise<Search[]>;
  getRecentSearches(userId: string, limit?: number): Promise<Search[]>;
  updateSearch(id: string, data: Partial<Search>): Promise<Search>;
  
  // Saved search operations
  saveSearch(savedSearch: InsertSavedSearch): Promise<SavedSearch>;
  getSavedSearches(userId: string): Promise<SavedSearch[]>;
  unsaveSearch(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Search operations
  async createSearch(searchData: InsertSearch): Promise<Search> {
    const [search] = await db.insert(searches).values(searchData).returning();
    return search;
  }

  async getSearch(id: string): Promise<Search | undefined> {
    const [search] = await db.select().from(searches).where(eq(searches.id, id));
    return search;
  }

  async getUserSearches(userId: string): Promise<Search[]> {
    return await db
      .select()
      .from(searches)
      .where(eq(searches.userId, userId))
      .orderBy(desc(searches.createdAt));
  }

  async getRecentSearches(userId: string, limit: number = 5): Promise<Search[]> {
    return await db
      .select()
      .from(searches)
      .where(eq(searches.userId, userId))
      .orderBy(desc(searches.createdAt))
      .limit(limit);
  }

  async updateSearch(id: string, data: Partial<Search>): Promise<Search> {
    const [updated] = await db
      .update(searches)
      .set(data)
      .where(eq(searches.id, id))
      .returning();
    return updated;
  }

  // Saved search operations
  async saveSearch(savedSearchData: InsertSavedSearch): Promise<SavedSearch> {
    const [savedSearch] = await db
      .insert(savedSearches)
      .values(savedSearchData)
      .returning();
    return savedSearch;
  }

  async getSavedSearches(userId: string): Promise<SavedSearch[]> {
    return await db
      .select()
      .from(savedSearches)
      .where(eq(savedSearches.userId, userId))
      .orderBy(desc(savedSearches.createdAt));
  }

  async unsaveSearch(id: string): Promise<void> {
    await db.delete(savedSearches).where(eq(savedSearches.id, id));
  }
}

export const storage = new DatabaseStorage();
